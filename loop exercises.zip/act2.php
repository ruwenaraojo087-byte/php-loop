<?php
//exercise 2: The Shopping List (foreach loop)

$items = ["Rice", "Milk", "Eggs", "Bread", "Sugar"];

foreach ($items as $item) {
    echo "- " . $item . "\n";
}
?>