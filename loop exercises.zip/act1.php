<?php
//exercise 1: The Basic Counter (for loop)

for ($i = 1; $i <= 20; $i++) {
    echo $i . "\n";
}

for ($i = 2; $i <= 20; $i += 2) {
    echo $i . "\n";
}
?>