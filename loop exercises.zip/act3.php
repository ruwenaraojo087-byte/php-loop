<?php
//exercise 3: The Rocket Countdown ( while loop)

$count = 10;

while ($count >= 1) {
    echo $count . "\n";
    $count--;
}

echo "Blast off!\n";
?>